/*
 *  This File is required to be able to use dotnet cli to restore the runtime, since it requires a Main method.
 *  Do not change/modify this file. 
 */

using System;

namespace DummyApplication
{
    public class Program
    {
        public static int Main(string[] args)
        {
            return 0;
        }
    }
}